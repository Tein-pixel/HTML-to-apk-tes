package com.tein.builder.engine;

/** Membaca ukuran PNG dari header IHDR (tanpa dekode gambar). */
public final class PngInfo {
    private PngInfo() {}

    private static final int[] SIG = {0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A};

    /** @return {lebar, tinggi} atau null jika bukan PNG. */
    public static int[] size(byte[] d) {
        if (d == null || d.length < 24) return null;
        for (int i = 0; i < 8; i++) {
            if ((d[i] & 0xFF) != SIG[i]) return null;
        }
        if (d[12] != 'I' || d[13] != 'H' || d[14] != 'D' || d[15] != 'R') return null;
        return new int[] {be32(d, 16), be32(d, 20)};
    }

    private static int be32(byte[] d, int o) {
        return ((d[o] & 0xFF) << 24) | ((d[o + 1] & 0xFF) << 16) | ((d[o + 2] & 0xFF) << 8) | (d[o + 3] & 0xFF);
    }
}
