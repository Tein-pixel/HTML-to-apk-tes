package com.tein.builder;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Menyalin APK ke folder Download publik (Android 10+ lewat MediaStore, tanpa izin penyimpanan). */
final class Saver {
    private Saver() {}

    static String saveApk(Context c, File apk, String displayName) throws IOException {
        ContentResolver r = c.getContentResolver();
        ContentValues v = new ContentValues();
        v.put(MediaStore.MediaColumns.DISPLAY_NAME, displayName);
        v.put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive");
        v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/TEIN");
        v.put(MediaStore.MediaColumns.IS_PENDING, 1);
        Uri uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
        if (uri == null) throw new IOException("Tidak bisa membuat file di Download");
        OutputStream os = r.openOutputStream(uri);
        if (os == null) throw new IOException("Tidak bisa menulis file");
        try {
            InputStream in = new FileInputStream(apk);
            try {
                byte[] buf = new byte[65536];
                int n;
                while ((n = in.read(buf)) > 0) os.write(buf, 0, n);
            } finally {
                in.close();
            }
        } finally {
            os.close();
        }
        ContentValues done = new ContentValues();
        done.put(MediaStore.MediaColumns.IS_PENDING, 0);
        r.update(uri, done, null, null);
        return "Download/TEIN/" + displayName;
    }
}
