package com.tein.builder.engine;

/** Kontrak antara template (modul :shell) dan builder (modul :app). */
public final class Spec {
    private Spec() {}

    public static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    public static final String ENTRY_CONFIG = "assets/tein/config.json";
    public static final String ENTRY_SPLASH = "assets/tein/splash.png";
    public static final String WWW_PREFIX = "assets/www/";

    /** Grup izin: satu saklar di UI = beberapa izin + fitur di manifest template. */
    public static final class Group {
        public final String id;
        public final String label;
        public final String hint;
        public final boolean defaultOn;
        public final String[] permissions;
        public final String[] features;

        Group(String id, String label, String hint, boolean defaultOn, String[] permissions, String[] features) {
            this.id = id;
            this.label = label;
            this.hint = hint;
            this.defaultOn = defaultOn;
            this.permissions = permissions;
            this.features = features;
        }
    }

    private static String[] a(String... s) {
        return s;
    }

    /** Semua nama di sini HARUS ada di shell/src/main/AndroidManifest.xml. */
    public static final Group[] GROUPS = new Group[] {
        new Group("internet", "Internet", "Wajib untuk mode Website atau API online", true,
                a("android.permission.INTERNET"), a()),
        new Group("network", "Status jaringan", "Mendeteksi online / offline", true,
                a("android.permission.ACCESS_NETWORK_STATE"), a()),
        new Group("vibrate", "Getar", "navigator.vibrate dan TeinNative.vibrate", true,
                a("android.permission.VIBRATE"), a()),
        new Group("storage", "Simpan unduhan (Android 9 ke bawah)", "Menyimpan file ke folder Download", true,
                a("android.permission.WRITE_EXTERNAL_STORAGE"), a()),
        new Group("notifications", "Notifikasi", "Notification API dan TeinNative.notify (Android 13+)", false,
                a("android.permission.POST_NOTIFICATIONS"), a()),
        new Group("camera", "Kamera", "getUserMedia video, foto, scan QR", false,
                a("android.permission.CAMERA"),
                a("android.hardware.camera", "android.hardware.camera.autofocus")),
        new Group("microphone", "Mikrofon", "getUserMedia audio, rekam suara", false,
                a("android.permission.RECORD_AUDIO", "android.permission.MODIFY_AUDIO_SETTINGS"),
                a("android.hardware.microphone")),
        new Group("location", "Lokasi (GPS)", "navigator.geolocation", false,
                a("android.permission.ACCESS_FINE_LOCATION", "android.permission.ACCESS_COARSE_LOCATION"),
                a("android.hardware.location", "android.hardware.location.gps")),
    };

    public static Group find(String id) {
        for (Group g : GROUPS) {
            if (g.id.equals(id)) return g;
        }
        return null;
    }
}
