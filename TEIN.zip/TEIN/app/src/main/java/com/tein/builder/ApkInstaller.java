package com.tein.builder;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/** Memasang APK lewat PackageInstaller (tanpa FileProvider). */
final class ApkInstaller {
    private ApkInstaller() {}

    /** @return false bila pengguna perlu mengizinkan "Pasang aplikasi tidak dikenal" dulu. */
    static boolean install(Context ctx, File apk) throws IOException {
        PackageManager pm = ctx.getPackageManager();
        if (!pm.canRequestPackageInstalls()) {
            Intent i = new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.getPackageName()));
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(i);
            return false;
        }
        PackageInstaller installer = pm.getPackageInstaller();
        PackageInstaller.SessionParams params = new PackageInstaller.SessionParams(
                PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int id = installer.createSession(params);
        PackageInstaller.Session session = installer.openSession(id);
        try {
            InputStream in = new FileInputStream(apk);
            try {
                OutputStream out = session.openWrite("base.apk", 0, apk.length());
                try {
                    byte[] buf = new byte[65536];
                    int n;
                    while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    session.fsync(out);
                } finally {
                    out.close();
                }
            } finally {
                in.close();
            }
            Intent cb = new Intent(ctx, InstallReceiver.class);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            PendingIntent pi = PendingIntent.getBroadcast(ctx, id, cb, flags);
            session.commit(pi.getIntentSender());
        } finally {
            session.close();
        }
        return true;
    }
}
