package com.tein.builder.engine;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.nio.charset.Charset;
import java.security.GeneralSecurityException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.SecureRandom;
import java.security.Signature;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.security.spec.PKCS8EncodedKeySpec;
import java.util.Calendar;
import java.util.TimeZone;

/**
 * Pembuat kunci RSA + sertifikat X.509 self-signed (DER ditulis manual, tanpa BouncyCastle)
 * untuk menandatangani APK hasil build.
 */
public final class Cert {
    private Cert() {}

    private static final Charset UTF8 = Charset.forName("UTF-8");
    private static final byte[] MAGIC = "TEINKEY1".getBytes(UTF8);

    public static final class KeyMaterial {
        public final PrivateKey key;
        public final X509Certificate cert;
        public final byte[] pkcs8;
        public final byte[] certDer;

        KeyMaterial(PrivateKey key, X509Certificate cert, byte[] pkcs8, byte[] certDer) {
            this.key = key;
            this.cert = cert;
            this.pkcs8 = pkcs8;
            this.certDer = certDer;
        }
    }

    public static KeyMaterial generate(String commonName) throws GeneralSecurityException, IOException {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        KeyPair kp = kpg.generateKeyPair();

        byte[] sigAlg = seq(OID_SHA256_RSA, NULL);
        byte[] name = seq(rdn(OID_CN, commonName), rdn(OID_O, "TEIN Builder"));

        long now = System.currentTimeMillis();
        byte[] validity = seq(time(now - 24L * 3600L * 1000L), time(now + 30L * 365L * 24L * 3600L * 1000L));

        byte[] sn = new byte[8];
        new SecureRandom().nextBytes(sn);
        sn[0] = (byte) ((sn[0] & 0x7F) | 0x01); // positif & tidak nol -> INTEGER DER minimal

        byte[] tbs = seq(
                tlv(0xA0, tlv(0x02, new byte[] {2})), // version v3
                tlv(0x02, sn),
                sigAlg,
                name,
                validity,
                name,
                kp.getPublic().getEncoded()); // SubjectPublicKeyInfo (sudah DER)

        Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(kp.getPrivate());
        s.update(tbs);
        byte[] sig = s.sign();

        byte[] bits = new byte[sig.length + 1];
        System.arraycopy(sig, 0, bits, 1, sig.length);
        byte[] der = seq(tbs, sigAlg, tlv(0x03, bits));

        X509Certificate cert = parse(der);
        cert.verify(kp.getPublic()); // self-check: tanda tangan sertifikat valid
        return new KeyMaterial(kp.getPrivate(), cert, kp.getPrivate().getEncoded(), der);
    }

    public static KeyMaterial load(byte[] pkcs8, byte[] certDer) throws GeneralSecurityException {
        PrivateKey k = KeyFactory.getInstance("RSA").generatePrivate(new PKCS8EncodedKeySpec(pkcs8));
        X509Certificate c = parse(certDer);
        return new KeyMaterial(k, c, pkcs8, certDer);
    }

    private static X509Certificate parse(byte[] der) throws GeneralSecurityException {
        return (X509Certificate) CertificateFactory.getInstance("X.509").generateCertificate(new ByteArrayInputStream(der));
    }

    // ------------------------------------------------- ekspor / impor kunci

    public static byte[] pack(byte[] pkcs8, byte[] certDer) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        DataOutputStream o = new DataOutputStream(bo);
        o.write(MAGIC);
        o.writeInt(pkcs8.length);
        o.write(pkcs8);
        o.writeInt(certDer.length);
        o.write(certDer);
        o.flush();
        return bo.toByteArray();
    }

    /** @return {pkcs8, certDer} */
    public static byte[][] unpack(byte[] blob) throws IOException {
        DataInputStream in = new DataInputStream(new ByteArrayInputStream(blob));
        byte[] m = new byte[MAGIC.length];
        in.readFully(m);
        for (int i = 0; i < m.length; i++) {
            if (m[i] != MAGIC[i]) throw new IOException("Bukan file kunci TEIN");
        }
        int n1 = in.readInt();
        if (n1 <= 0 || n1 > 65536) throw new IOException("File kunci rusak");
        byte[] a = new byte[n1];
        in.readFully(a);
        int n2 = in.readInt();
        if (n2 <= 0 || n2 > 65536) throw new IOException("File kunci rusak");
        byte[] b = new byte[n2];
        in.readFully(b);
        return new byte[][] {a, b};
    }

    // ------------------------------------------------------------- DER

    private static final byte[] NULL = {0x05, 0x00};
    private static final byte[] OID_SHA256_RSA = {0x06, 0x09, 0x2A, (byte) 0x86, 0x48, (byte) 0x86, (byte) 0xF7, 0x0D, 0x01, 0x01, 0x0B};
    private static final byte[] OID_CN = {0x06, 0x03, 0x55, 0x04, 0x03};
    private static final byte[] OID_O = {0x06, 0x03, 0x55, 0x04, 0x0A};

    private static byte[] rdn(byte[] oid, String value) throws IOException {
        return tlv(0x31, seq(oid, tlv(0x0C, value.getBytes(UTF8)))); // SET { SEQUENCE { OID, UTF8String } }
    }

    private static byte[] time(long millis) throws IOException {
        Calendar c = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        c.setTimeInMillis(millis);
        int y = c.get(Calendar.YEAR);
        String body = two(c.get(Calendar.MONTH) + 1) + two(c.get(Calendar.DAY_OF_MONTH)) + two(c.get(Calendar.HOUR_OF_DAY))
                + two(c.get(Calendar.MINUTE)) + two(c.get(Calendar.SECOND)) + "Z";
        if (y < 2050) {
            return tlv(0x17, (two(y % 100) + body).getBytes(UTF8)); // UTCTime
        }
        return tlv(0x18, (String.valueOf(y) + body).getBytes(UTF8)); // GeneralizedTime
    }

    private static String two(int v) {
        return v < 10 ? "0" + v : String.valueOf(v);
    }

    private static byte[] seq(byte[]... parts) throws IOException {
        return tlv(0x30, concat(parts));
    }

    private static byte[] concat(byte[]... parts) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        for (byte[] p : parts) bo.write(p);
        return bo.toByteArray();
    }

    private static byte[] tlv(int tag, byte[] content) throws IOException {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        bo.write(tag);
        int n = content.length;
        if (n < 0x80) {
            bo.write(n);
        } else if (n < 0x100) {
            bo.write(0x81);
            bo.write(n);
        } else if (n < 0x10000) {
            bo.write(0x82);
            bo.write(n >> 8);
            bo.write(n & 0xFF);
        } else {
            bo.write(0x83);
            bo.write(n >> 16);
            bo.write((n >> 8) & 0xFF);
            bo.write(n & 0xFF);
        }
        bo.write(content);
        return bo.toByteArray();
    }
}
