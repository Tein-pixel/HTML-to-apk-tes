package com.tein.builder.engine;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Merakit APK belum-bertanda-tangan dari template.apk:
 * salin dex/resources, tambal manifest, ganti ikon, tambah config + isi situs.
 */
public final class ApkAssembler {
    private ApkAssembler() {}

    public interface Icons {
        /** Mengembalikan PNG berukuran w x h untuk entri ikon bernama entryName. */
        byte[] render(String entryName, int w, int h) throws IOException;
    }

    public interface Www {
        void write(AlignedZipWriter z) throws IOException;
    }

    public static final class Plan {
        public final AxmlPatcher.Edits manifest = new AxmlPatcher.Edits();
        public Icons icons;
        public byte[] configJson;
        public byte[] splashPng;
        public Www www;
    }

    public static final class Result {
        public int iconsReplaced;
        public int entriesCopied;
        public final List<String> log = new ArrayList<String>();
    }

    public static Result assemble(File templateApk, OutputStream out, Plan plan) throws IOException {
        Result r = new Result();
        AlignedZipWriter z = new AlignedZipWriter(out);
        ZipFile zf = new ZipFile(templateApk);
        boolean sawManifest = false;
        boolean sawArsc = false;
        boolean sawDex = false;
        try {
            Enumeration<? extends ZipEntry> en = zf.entries();
            while (en.hasMoreElements()) {
                ZipEntry e = en.nextElement();
                if (e.isDirectory()) continue;
                String name = e.getName();
                if (name.startsWith("META-INF/")) continue; // tanda tangan lama / metadata build
                if (name.startsWith("assets/www/") || name.startsWith("assets/tein/")) continue;
                byte[] data = readAll(zf.getInputStream(e));
                if (name.equals("AndroidManifest.xml")) {
                    z.putDeflated(name, AxmlPatcher.patch(data, plan.manifest));
                    sawManifest = true;
                } else if (name.equals("resources.arsc")) {
                    z.putStored(name, data);
                    sawArsc = true;
                } else if (isLauncherPng(name) && plan.icons != null) {
                    int[] wh = PngInfo.size(data);
                    if (wh != null) {
                        z.putStored(name, plan.icons.render(name, wh[0], wh[1]));
                        r.iconsReplaced++;
                    } else {
                        z.putStored(name, data);
                    }
                } else {
                    if (name.endsWith(".dex")) sawDex = true;
                    z.putDeflated(name, data);
                }
                r.entriesCopied++;
            }
        } finally {
            zf.close();
        }
        if (!sawManifest) throw new IOException("Template tidak berisi AndroidManifest.xml");
        if (!sawArsc) throw new IOException("Template tidak berisi resources.arsc");
        if (!sawDex) throw new IOException("Template tidak berisi classes.dex");
        if (plan.configJson == null) throw new IOException("config.json belum dibuat");
        z.putDeflated(Spec.ENTRY_CONFIG, plan.configJson);
        if (plan.splashPng != null) z.putStored(Spec.ENTRY_SPLASH, plan.splashPng);
        if (plan.www != null) plan.www.write(z);
        z.close();
        return r;
    }

    static boolean isLauncherPng(String name) {
        if (!name.startsWith("res/") || !name.endsWith(".png")) return false;
        String base = name.substring(name.lastIndexOf('/') + 1);
        return base.equals("ic_launcher.png") || base.equals("ic_launcher_foreground.png")
                || base.equals("ic_launcher_background.png");
    }

    private static byte[] readAll(InputStream in) throws IOException {
        try {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            return bo.toByteArray();
        } finally {
            in.close();
        }
    }
}
