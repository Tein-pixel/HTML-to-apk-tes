package com.tein.builder;

import com.tein.builder.engine.Spec;

import java.io.File;
import java.util.LinkedHashSet;
import java.util.Set;

/** Semua pilihan pengguna untuk satu aplikasi yang akan dibuat. */
final class AppSpec {
    static final String SRC_FILE = "file"; // HTML atau ZIP (terdeteksi otomatis)
    static final String SRC_WEB = "web";

    String source = SRC_FILE;
    String name = "";
    String packageName = "";
    String versionName = "1.0";
    int versionCode = 1;

    File sourceFile;
    boolean sourceIsZip;
    String sourceLabel = "";
    String websiteUrl = "";

    File iconFile;
    File splashFile;

    final Set<String> perms = new LinkedHashSet<String>();
    boolean offlineCache = true;
    boolean fullscreen;
    boolean keepScreenOn;
    boolean zoom;
    boolean exitConfirm = true;
    String orientation = "auto";
    String externalLinks = "auto";
    String userAgent = "";
    String splashType = "off";
    String splashSpeed = "normal";
    int themeColor = 0xFF0F1412;

    AppSpec() {
        for (Spec.Group g : Spec.GROUPS) {
            if (g.defaultOn) perms.add(g.id);
        }
    }

    boolean isWeb() {
        return SRC_WEB.equals(source);
    }
}
