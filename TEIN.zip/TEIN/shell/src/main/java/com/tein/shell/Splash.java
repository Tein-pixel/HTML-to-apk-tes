package com.tein.shell;

import android.animation.Animator;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Layar pembuka (startup loading) bergaya WZH: static, fade, typewriter, pulse, tumble, atau gambar. */
final class Splash extends FrameLayout {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Animator> loops = new ArrayList<Animator>();
    private final ShellConfig cfg;
    private final float speed;
    private final int fg;
    private boolean minDone;
    private long minMs = 900;
    private Runnable onMin;

    Splash(Context c, ShellConfig cfg, Bitmap image) {
        super(c);
        this.cfg = cfg;
        if ("slow".equals(cfg.splashSpeed)) speed = 1.6f;
        else if ("fast".equals(cfg.splashSpeed)) speed = 0.6f;
        else speed = 1.0f;
        fg = ShellConfig.isLight(cfg.themeColor) ? 0xFF111111 : 0xFFFFFFFF;
        setBackgroundColor(cfg.themeColor);
        setClickable(true); // menahan sentuhan agar tidak tembus ke WebView
        build(image);
    }

    private void build(Bitmap image) {
        String t = cfg.splashType;
        if ("image".equals(t) && image != null) {
            buildImage(image);
            minMs = (long) (1500 * speed);
        } else if ("fade".equals(t)) {
            buildFade();
            minMs = (long) (1600 * speed);
        } else if ("typewriter".equals(t)) {
            buildTypewriter();
            minMs = (long) ((cfg.name.length() * 90 + 700) * speed);
        } else if ("pulse".equals(t)) {
            buildPulse();
            minMs = (long) (1900 * speed);
        } else if ("tumble".equals(t)) {
            buildTumble();
            minMs = (long) ((cfg.name.length() * 70 + 1100) * speed);
        } else {
            buildStatic();
            minMs = (long) (900 * speed);
        }
    }

    private float nameSize() {
        int n = cfg.name.length();
        return n > 14 ? 18f : (n > 9 ? 24f : 30f);
    }

    private TextView nameText(float sp) {
        TextView tv = new TextView(getContext());
        tv.setText(cfg.name);
        tv.setTextColor(fg);
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setLetterSpacing(0.06f);
        tv.setGravity(Gravity.CENTER);
        return tv;
    }

    private int dp(float v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void addCentered(View v) {
        addView(v, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    private void buildStatic() {
        addCentered(nameText(nameSize()));
    }

    private void buildFade() {
        TextView tv = nameText(nameSize());
        tv.setAlpha(0f);
        tv.setTranslationY(dp(40));
        addCentered(tv);
        tv.animate().alpha(1f).translationY(0f).setDuration((long) (900 * speed))
                .setInterpolator(new DecelerateInterpolator()).start();
    }

    private void buildTypewriter() {
        final TextView tv = nameText(nameSize());
        tv.setText("");
        addCentered(tv);
        final String full = cfg.name;
        final int total = full.codePointCount(0, full.length());
        final int[] shown = {0};
        Runnable typer = new Runnable() {
            @Override
            public void run() {
                shown[0]++;
                int end = full.offsetByCodePoints(0, Math.min(shown[0], total));
                tv.setText(full.substring(0, end));
                if (shown[0] < total) h.postDelayed(this, (long) (90 * speed));
            }
        };
        h.postDelayed(typer, 250);
    }

    private void buildPulse() {
        FrameLayout box = new FrameLayout(getContext());
        int size = dp(240);
        addView(box, new FrameLayout.LayoutParams(size, size, Gravity.CENTER));
        for (int k = 0; k < 3; k++) {
            View ring = new View(getContext());
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setStroke(dp(2), fg);
            g.setColor(Color.TRANSPARENT);
            ring.setBackground(g);
            ring.setAlpha(0f);
            box.addView(ring, new FrameLayout.LayoutParams(dp(110), dp(110), Gravity.CENTER));
            ObjectAnimator a = ObjectAnimator.ofPropertyValuesHolder(ring,
                    PropertyValuesHolder.ofFloat(View.SCALE_X, 0.4f, 2.0f),
                    PropertyValuesHolder.ofFloat(View.SCALE_Y, 0.4f, 2.0f),
                    PropertyValuesHolder.ofFloat(View.ALPHA, 0.7f, 0f));
            a.setDuration((long) (1500 * speed));
            a.setStartDelay((long) (k * 450 * speed));
            a.setRepeatCount(ValueAnimator.INFINITE);
            a.setInterpolator(new LinearInterpolator());
            loops.add(a);
            a.start();
        }
        TextView tv = nameText(Math.min(nameSize(), 22f));
        box.addView(tv, new FrameLayout.LayoutParams(FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.WRAP_CONTENT, Gravity.CENTER));
    }

    private void buildTumble() {
        LinearLayout row = new LinearLayout(getContext());
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER);
        addCentered(row);
        String s = cfg.name;
        int idx = 0;
        int off = 0;
        while (off < s.length()) {
            int cp = s.codePointAt(off);
            off += Character.charCount(cp);
            TextView tv = nameText(nameSize());
            tv.setText(new String(Character.toChars(cp)));
            tv.setAlpha(0f);
            tv.setTranslationY(-dp(160));
            tv.setRotation(-300f);
            row.addView(tv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            tv.animate().alpha(1f).translationY(0f).rotation(0f)
                    .setDuration((long) (700 * speed)).setStartDelay((long) (idx * 70 * speed))
                    .setInterpolator(new OvershootInterpolator(1.4f)).start();
            idx++;
        }
    }

    private void buildImage(Bitmap image) {
        ImageView iv = new ImageView(getContext());
        iv.setImageBitmap(image);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setAlpha(0f);
        int w = getResources().getDisplayMetrics().widthPixels * 6 / 10;
        addView(iv, new FrameLayout.LayoutParams(w, w, Gravity.CENTER));
        iv.animate().alpha(1f).setDuration((long) (600 * speed)).start();
    }

    void start(Runnable cb) {
        onMin = cb;
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                minDone = true;
                if (onMin != null) onMin.run();
            }
        }, minMs);
    }

    boolean isMinDone() {
        return minDone;
    }

    void dismiss(Runnable after) {
        cancel();
        animate().alpha(0f).setDuration(250).withEndAction(after).start();
    }

    void cancel() {
        h.removeCallbacksAndMessages(null);
        for (Animator a : loops) a.cancel();
        loops.clear();
    }
}
