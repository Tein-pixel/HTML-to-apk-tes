package com.tein.shell;

import android.content.Context;
import android.graphics.Color;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;

/** Konfigurasi yang ditulis TEIN ke assets/tein/config.json saat membuat APK. */
final class ShellConfig {
    String name = "App";
    String mode = "local"; // local | website
    String entry = "index.html";
    String url = "";
    String orientation = "auto"; // auto | portrait | landscape | sensor
    boolean fullscreen;
    boolean keepScreenOn;
    boolean zoom;
    boolean offlineCache = true;
    String externalLinks = "auto"; // auto | browser | inapp
    String userAgent = "";
    int themeColor = 0xFF0F1412;
    boolean exitConfirm = true;
    boolean notifications;
    String splashType = "off"; // off | static | fade | typewriter | pulse | tumble | image
    String splashSpeed = "normal"; // slow | normal | fast

    boolean isLocal() {
        return "local".equals(mode);
    }

    static ShellConfig load(Context ctx) {
        ShellConfig c = new ShellConfig();
        InputStream in = null;
        try {
            in = ctx.getAssets().open("tein/config.json");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            JSONObject j = new JSONObject(new String(bo.toByteArray(), "UTF-8"));
            c.name = j.optString("name", c.name);
            c.mode = j.optString("mode", c.mode);
            c.entry = j.optString("entry", c.entry);
            c.url = j.optString("url", c.url);
            c.orientation = j.optString("orientation", c.orientation);
            c.fullscreen = j.optBoolean("fullscreen", c.fullscreen);
            c.keepScreenOn = j.optBoolean("keepScreenOn", c.keepScreenOn);
            c.zoom = j.optBoolean("zoom", c.zoom);
            c.offlineCache = j.optBoolean("offlineCache", c.offlineCache);
            c.externalLinks = j.optString("externalLinks", c.externalLinks);
            c.userAgent = j.optString("userAgent", c.userAgent);
            c.themeColor = parseColor(j.optString("themeColor", ""), c.themeColor);
            c.exitConfirm = j.optBoolean("exitConfirm", c.exitConfirm);
            c.notifications = j.optBoolean("notifications", c.notifications);
            c.splashType = j.optString("splash", c.splashType);
            c.splashSpeed = j.optString("splashSpeed", c.splashSpeed);
        } catch (Exception e) {
            // config hilang/rusak: pakai nilai bawaan
        } finally {
            if (in != null) {
                try {
                    in.close();
                } catch (Exception ignored) {
                    // abaikan
                }
            }
        }
        return c;
    }

    static int parseColor(String s, int def) {
        try {
            if (s == null || s.length() == 0) return def;
            return Color.parseColor(s);
        } catch (Exception e) {
            return def;
        }
    }

    static boolean isLight(int color) {
        double l = 0.299 * Color.red(color) + 0.587 * Color.green(color) + 0.114 * Color.blue(color);
        return l > 160;
    }
}
