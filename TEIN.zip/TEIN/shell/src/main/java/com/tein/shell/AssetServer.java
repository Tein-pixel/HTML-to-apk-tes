package com.tein.shell;

import android.content.res.AssetManager;
import android.net.Uri;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;

import java.io.ByteArrayInputStream;
import java.io.FilterInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Menyajikan isi assets/www lewat origin https virtual (https://appassets.androidplatform.net/).
 * Dengan origin ini fetch(), ES module, localStorage, IndexedDB, geolocation dan getUserMedia
 * bekerja normal (tidak bisa dengan file://).
 */
final class AssetServer {
    static final String HOST = "appassets.androidplatform.net";
    static final String ORIGIN = "https://" + HOST;

    private final AssetManager assets;
    private final String entry;

    AssetServer(AssetManager am, String entry) {
        this.assets = am;
        this.entry = (entry == null || entry.length() == 0) ? "index.html" : entry;
    }

    static String startUrl(String entry) {
        StringBuilder sb = new StringBuilder(ORIGIN).append('/');
        String[] parts = entry.split("/");
        for (int i = 0; i < parts.length; i++) {
            if (i > 0) sb.append('/');
            sb.append(Uri.encode(parts[i]));
        }
        return sb.toString();
    }

    boolean owns(Uri u) {
        return u != null && "https".equals(u.getScheme()) && HOST.equalsIgnoreCase(u.getHost());
    }

    /** @return null jika URL bukan milik origin virtual (biarkan WebView mengurusnya). */
    WebResourceResponse handle(WebResourceRequest r) {
        Uri u = r.getUrl();
        if (!owns(u)) return null;
        String method = r.getMethod();
        if (method != null && !"GET".equalsIgnoreCase(method) && !"HEAD".equalsIgnoreCase(method)) {
            return error(405, "Method Not Allowed");
        }
        String path = u.getPath();
        if (path == null) path = "/";
        String rel = path.startsWith("/") ? path.substring(1) : path;
        if (rel.length() == 0 || rel.endsWith("/")) rel = rel + "index.html";
        if (rel.contains("..")) return error(403, "Forbidden");

        InputStream in = open("www/" + rel);
        if (in == null && rel.equals("index.html")) {
            in = open("www/" + entry);
            rel = entry;
        }
        if (in == null && !hasExtension(rel)) { // rute SPA: tampilkan halaman utama
            in = open("www/" + entry);
            rel = entry;
        }
        if (in == null) return error(404, "Not Found");

        String mime = mimeOf(rel);
        String enc = isText(mime) ? "utf-8" : null;
        Map<String, String> h = new HashMap<String, String>();
        h.put("Accept-Ranges", "bytes");
        h.put("Access-Control-Allow-Origin", "*");

        String range = header(r.getRequestHeaders(), "Range");
        long total;
        try {
            total = in.available();
        } catch (IOException e) {
            total = -1;
        }
        if (range != null && total > 0 && range.startsWith("bytes=")) {
            long start = 0;
            long end = total - 1;
            try {
                String spec = range.substring(6);
                int dash = spec.indexOf('-');
                String a = spec.substring(0, dash).trim();
                String b = spec.substring(dash + 1).trim();
                if (a.length() == 0) {
                    start = Math.max(0, total - Long.parseLong(b));
                } else {
                    start = Long.parseLong(a);
                    if (b.length() > 0) end = Math.min(Long.parseLong(b), total - 1);
                }
            } catch (Exception ex) {
                start = 0;
                end = total - 1;
            }
            if (start > end || start >= total) {
                closeQuietly(in);
                Map<String, String> h2 = new HashMap<String, String>();
                h2.put("Content-Range", "bytes */" + total);
                return new WebResourceResponse("text/plain", "utf-8", 416, "Range Not Satisfiable", h2,
                        new ByteArrayInputStream(new byte[0]));
            }
            try {
                skipFully(in, start);
            } catch (IOException e) {
                closeQuietly(in);
                return error(500, "Read error");
            }
            long len = end - start + 1;
            h.put("Content-Range", "bytes " + start + "-" + end + "/" + total);
            h.put("Content-Length", String.valueOf(len));
            return new WebResourceResponse(mime, enc, 206, "Partial Content", h, new Limited(in, len));
        }
        return new WebResourceResponse(mime, enc, 200, "OK", h, in);
    }

    InputStream openRaw(String relPath) {
        return open("www/" + relPath);
    }

    private InputStream open(String p) {
        try {
            return assets.open(p, AssetManager.ACCESS_STREAMING);
        } catch (IOException e) {
            return null;
        }
    }

    private static WebResourceResponse error(int code, String reason) {
        return new WebResourceResponse("text/plain", "utf-8", code, reason, new HashMap<String, String>(),
                new ByteArrayInputStream(reason.getBytes()));
    }

    private static String header(Map<String, String> headers, String key) {
        if (headers == null) return null;
        for (Map.Entry<String, String> e : headers.entrySet()) {
            if (key.equalsIgnoreCase(e.getKey())) return e.getValue();
        }
        return null;
    }

    private static boolean hasExtension(String rel) {
        String last = rel.substring(rel.lastIndexOf('/') + 1);
        return last.indexOf('.') >= 0;
    }

    private static void skipFully(InputStream in, long n) throws IOException {
        long left = n;
        while (left > 0) {
            long s = in.skip(left);
            if (s <= 0) {
                if (in.read() < 0) break;
                s = 1;
            }
            left -= s;
        }
    }

    private static void closeQuietly(InputStream in) {
        try {
            in.close();
        } catch (IOException ignored) {
            // abaikan
        }
    }

    static boolean isText(String mime) {
        return mime.startsWith("text/") || mime.equals("application/json") || mime.equals("application/xml")
                || mime.equals("image/svg+xml") || mime.equals("application/manifest+json");
    }

    static String mimeOf(String name) {
        int dot = name.lastIndexOf('.');
        String ext = dot < 0 ? "" : name.substring(dot + 1).toLowerCase(Locale.ROOT);
        switch (ext) {
            case "html": case "htm": return "text/html";
            case "css": return "text/css";
            case "js": case "mjs": return "text/javascript";
            case "json": return "application/json";
            case "webmanifest": return "application/manifest+json";
            case "xml": return "application/xml";
            case "txt": return "text/plain";
            case "csv": return "text/csv";
            case "svg": return "image/svg+xml";
            case "png": return "image/png";
            case "jpg": case "jpeg": return "image/jpeg";
            case "gif": return "image/gif";
            case "webp": return "image/webp";
            case "avif": return "image/avif";
            case "ico": return "image/x-icon";
            case "bmp": return "image/bmp";
            case "woff": return "font/woff";
            case "woff2": return "font/woff2";
            case "ttf": return "font/ttf";
            case "otf": return "font/otf";
            case "mp3": return "audio/mpeg";
            case "wav": return "audio/wav";
            case "ogg": case "oga": return "audio/ogg";
            case "m4a": return "audio/mp4";
            case "aac": return "audio/aac";
            case "mp4": case "m4v": return "video/mp4";
            case "webm": return "video/webm";
            case "wasm": return "application/wasm";
            case "pdf": return "application/pdf";
            case "zip": return "application/zip";
            default: return "application/octet-stream";
        }
    }

    private static final class Limited extends FilterInputStream {
        private long left;

        Limited(InputStream in, long len) {
            super(in);
            left = len;
        }

        @Override
        public int read() throws IOException {
            if (left <= 0) return -1;
            int b = super.read();
            if (b >= 0) left--;
            return b;
        }

        @Override
        public int read(byte[] buf, int off, int len) throws IOException {
            if (left <= 0) return -1;
            int n = super.read(buf, off, (int) Math.min((long) len, left));
            if (n > 0) left -= n;
            return n;
        }
    }
}
